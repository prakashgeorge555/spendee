package com.example.spendee.feature_current_balance.domain.use_case

data class BalanceUseCases(
    val getBalance: GetCurrentBalance,
    val updateBalance: UpdateBalance
)
