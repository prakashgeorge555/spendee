# Spendee

Spendee is an Android application that helps users manage their finances efficiently. Built with a focus on user experience, the app allows for setting balance, managing expenses, budget and financial goals with an intuitive and responsive design.
